package bfrest

import (
	"crypto/tls"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sync"
	"time"
)

// Pool manages a set of connections.
type Pool struct {
	connections chan *BFConnection
	factory     func() (*BFConnection, error)
	closed      bool
	mutex       sync.Mutex
}

// BFConnection represents a connection configuration.
type BFConnection struct {
	URL      string
	Username string
	Password string
	Conn     http.Client
}

// Get sends a GET request to the specified URL and returns the response body as a string.

func (c *BFConnection) Get(urlStr string) (string, error) {
	parsedURL, err := url.Parse(urlStr)
	if err != nil {
		return "", err
	}

	// Compare the non-directory components of the BFConnection URL and the parsed URL
	if c.URL != parsedURL.Scheme+"://"+parsedURL.Host {
		return "", fmt.Errorf("URL does not match")
	}

	// Properly encode the URL by reconstructing it with encoded query parameters
	encodedURL := parsedURL.Scheme + "://" + parsedURL.Host + parsedURL.Path
	if parsedURL.RawQuery != "" {
		// Re-encode the query parameters to ensure proper escaping
		values, err := url.ParseQuery(parsedURL.RawQuery)
		if err != nil {
			return "", fmt.Errorf("failed to parse query parameters: %v", err)
		}
		encodedURL += "?" + values.Encode()
	}

	req, err := http.NewRequest("GET", encodedURL, nil)
	if err != nil {
		return "", err
	}

	req.SetBasicAuth(c.Username, c.Password)

	resp, err := c.Conn.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	return string(body), nil
}

// createBFConnection creates a new BFConnection instance.
func createBFConnection(urlStr string, username string, password string) (*BFConnection, error) {
	// Initialize the http.Transport. You might want to customize this based on your requirements.
	transport := http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	// Initialize the http.Client. You can also customize this as needed.
	client := http.Client{
		Transport: &transport,
		Timeout: 120 * time.Second,
	}

	// Return a new BFConnection with the provided details.
	return &BFConnection{
		URL:      urlStr,
		Username: username,
		Password: password,
		Conn:     client,
	}, nil
}

// NewPool creates a new pool of connections.
func NewPool(urlStr, username, password string, size int) (*Pool, error) {
	if size <= 0 {
		return nil, fmt.Errorf("size value too small")
	}

	factory := func() (*BFConnection, error) {
		return createBFConnection(urlStr, username, password)
	}

	pool := &Pool{
		connections: make(chan *BFConnection, size),
		factory:     factory,
		closed:      false,
		mutex:       sync.Mutex{},
	}

	pool.mutex.Lock()
	defer pool.mutex.Unlock()

	for i := 0; i < size; i++ {
		connection, err := factory()
		if err != nil {
			return nil, err
		}
		pool.connections <- connection
	}

	return pool, nil
}

// Return number of connections in the pool.
func (p *Pool) Len() int {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	return len(p.connections)
}

// Acquire retrieves a connection from the pool.

func (p *Pool) Acquire() (*BFConnection, error) {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	//	fmt.Println("Acquire")
	if p.closed {
		return nil, fmt.Errorf("pool is closed")
	}

	select {
	case conn := <-p.connections:
		return conn, nil
	case <-time.After(30 * time.Second):
		return nil, fmt.Errorf("timeout on connection Acquire")
	}
}

// Release returns a connection to the pool.
func (p *Pool) Release(c *BFConnection) {
	//	fmt.Println("Release")
	if p.closed {
		// handle closed pool scenario, maybe discard the connection
		return
	}

	p.connections <- c
}

// Close closes the pool and releases all connections.
func (p *Pool) Close() {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	if p.closed {
		return
	}

	p.closed = true
	close(p.connections)
	for r := range p.connections {
		// Close or cleanup the resource.
		r.Conn.CloseIdleConnections()
	}
}
